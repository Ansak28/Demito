package pregunta2;

public class Mensaje {
    
    private CabeceraMensaje cabecera;
    private CuerpoMensaje cuerpo;

    public void setCabecera(CabeceraMensaje cabecera) {
        this.cabecera = cabecera;
    }

    public void setCuerpo(CuerpoMensaje cuerpo) {
        this.cuerpo = cuerpo;
    }
    
    
}
