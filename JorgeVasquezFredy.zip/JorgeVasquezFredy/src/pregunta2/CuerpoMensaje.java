package pregunta2;

class CuerpoMensaje {
    private DocumentoAdjunto doc;
    private String texto;

    

    public void setDoc(DocumentoAdjunto doc) {
        this.doc = doc;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
    
}
