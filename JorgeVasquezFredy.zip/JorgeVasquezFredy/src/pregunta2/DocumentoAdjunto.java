package pregunta2;

class DocumentoAdjunto {
    private String archivo;

    

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }
    
    
}
