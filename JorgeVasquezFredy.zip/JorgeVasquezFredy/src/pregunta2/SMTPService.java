package pregunta2;

class SMTPService {

    void enviarMail(String mensajeEncriptado) {
        System.out.println("Mensaje Enviado: "+mensajeEncriptado);
    }    
}
