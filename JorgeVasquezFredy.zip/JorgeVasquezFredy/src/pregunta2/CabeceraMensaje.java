package pregunta2;

class CabeceraMensaje {
    private String para;
    private String asunto;    

    

    public void setPara(String para) {
        this.para = para;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }
    
}
