package pregunta3;

public abstract class CARRERA {
    
}
