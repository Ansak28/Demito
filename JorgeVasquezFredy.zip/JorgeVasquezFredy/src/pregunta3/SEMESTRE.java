package pregunta3;

public abstract class SEMESTRE {
    I, II, III, IV, V    
}
