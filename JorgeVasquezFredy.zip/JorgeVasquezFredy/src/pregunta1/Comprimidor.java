/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta1;

/**
 *
 * @author Fredy
 */
public abstract class Comprimidor {
    public abstract  Archivo FArchivo();
    
}
