/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta1;

/**
 *
 * @author user
 */
public class ArchivoRar {
    public void comprimir(String nombreArchivo){
        System.out.println("El archivo fue comprimido en formato RAR");
    }
    
}
