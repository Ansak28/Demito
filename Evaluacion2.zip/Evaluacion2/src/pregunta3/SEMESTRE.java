package pregunta3;

public enum SEMESTRE {
    I, II, III, IV, V    
}
