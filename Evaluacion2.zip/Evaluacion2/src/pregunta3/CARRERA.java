package pregunta3;

public enum CARRERA {
    IS, II, IC
}
