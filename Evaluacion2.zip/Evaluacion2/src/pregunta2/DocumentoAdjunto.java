package pregunta2;

class DocumentoAdjunto {
    private String archivo;

    public DocumentoAdjunto(String archivo) {
        this.archivo = archivo;
    }
    
    
}
