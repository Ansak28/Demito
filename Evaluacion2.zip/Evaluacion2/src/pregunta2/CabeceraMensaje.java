package pregunta2;

class CabeceraMensaje {
    private String para;
    private String asunto;    

    public CabeceraMensaje(String para, String asunto) {
        this.para = para;
        this.asunto = asunto;
    }
    
}
